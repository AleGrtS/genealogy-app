#!/bin/bash
cd /var/www/genealogy-app/server
npx ts-node scripts/seed-database.ts

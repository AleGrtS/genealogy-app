========================================
🌳 GENEALOGY APP - ПОЛНАЯ РЕЗЕРВНАЯ КОПИЯ
========================================

📅 Дата создания: Wed Feb 18 10:28:05 PM EET 2026
📁 Версия: v0.6.0 (с загрузкой фото)

📊 СТАТИСТИКА:
   👥 Людей: 1
   📸 Фотографий: 1
   🔗 Отношений: 0

📂 СТРУКТУРА:
   server/    - Backend код (Node.js + Express)
   client/    - Frontend код (React + TypeScript)
   uploads/   - Загруженные фотографии
   database/  - База данных SQLite

🔧 ФУНКЦИОНАЛ:
   ✅ Управление людьми (CRUD)
   ✅ Управление отношениями
   ✅ Визуализация семейного дерева
   ✅ Поиск и фильтрация
   ✅ Загрузка фотографий
   ✅ Интерактивное дерево

🚀 ЗАПУСК ПРОЕКТА:
   1. Backend: cd server && npm install && npm run dev
   2. Frontend: cd client && npm install && npm run dev
   3. Открыть: http://localhost:5173

📝 ЗАВИСИМОСТИ:
   Backend: express, sequelize, sqlite3, multer, uuid
   Frontend: react, typescript, axios, vis-network

========================================

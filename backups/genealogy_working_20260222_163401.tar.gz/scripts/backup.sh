#!/bin/bash
BACKUP_DIR="backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="genealogy_working_${TIMESTAMP}"

mkdir -p $BACKUP_DIR

echo "📦 Создание резервной копии: $BACKUP_NAME"

# Копируем все важные файлы
tar -czf "$BACKUP_DIR/$BACKUP_NAME.tar.gz" \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='*.log' \
  server/ client/ shared/ scripts/ \
  *.md *.json *.sh

echo "✅ Резервная копия создана: $BACKUP_DIR/$BACKUP_NAME.tar.gz"
ls -lh "$BACKUP_DIR/$BACKUP_NAME.tar.gz"

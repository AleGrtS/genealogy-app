# 🌳 Genealogy App

Приложение для построения и управления генеалогическим древом.

## 🚀 Технологии

### Backend
- Node.js + Express + TypeScript
- SQLite (с Sequelize ORM)
- REST API

### Frontend
- React 19 + TypeScript
- Vite (сборщик)
- Чистый CSS (без UI фреймворков)

## 📁 Структура проекта

genealogy-app/
├── client/ # Frontend приложение
│ ├── src/
│ │ ├── components/ # React компоненты
│ │ ├── services/ # API клиент
│ │ └── ...
├── server/ # Backend приложение
│ ├── src/
│ │ ├── controllers/ # Контроллеры API
│ │ ├── models/ # Модели данных
│ │ ├── routes/ # Маршруты API
│ │ └── ...
├── shared/ # Общие типы и утилиты
├── uploads/ # Загружаемые файлы
└── docs/ # Документация 

## 🔧 Установка и запуск

### 1. Клонирование репозитория
```bash
git clone <ваш-repo-url>
cd genealogy-app 
2. Установка зависимостей Backend
bash

cd server
npm install

3. Установка зависимостей Frontend
bash

cd client
npm install 
4. Запуск Backend
bash

cd server
npm run dev
# Сервер запустится на http://localhost:3001

5. Запуск Frontend
bash

cd client
npm run dev
# Приложение будет доступно на http://localhost:5173 
📡 API Endpoints

    GET /api/health - Проверка работы сервера

    GET /api/persons - Получить всех людей

    POST /api/persons - Создать человека

    GET /api/persons/:id - Получить человека по ID

    GET /api/relationships - Получить все отношения

    POST /api/relationships - Создать отношение

🗄️ База данных

Используется SQLite с Sequelize ORM. Модели:

    Person - информация о человеке

    Relationship - отношения между людьми

📝 История версий
v0.2 (Текущая)

    ✅ CRUD операции для людей

    ✅ Управление отношениями (родитель, супруг, брат/сестра)

    ✅ Интерфейс с табами

    ✅ SQLite база данных

v0.1

    Базовая структура проекта

    CRUD для людей

    Простой интерфейс

👥 Разработчики

    Alexandr Gorot
📄 Лицензия

MIT

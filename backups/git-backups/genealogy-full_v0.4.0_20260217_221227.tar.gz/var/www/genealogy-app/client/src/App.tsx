import { useState, useEffect } from 'react';
import type { Person, Relationship } from './services/api';
import { personApi, relationshipApi } from './services/api';
import EditPersonModal from './components/EditPersonModal';

function App() {
  const [persons, setPersons] = useState<Person[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'persons' | 'relationships'>('persons');
  
  // Модальное окно редактирования
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  
  // Форма для создания отношения
  const [newRelationship, setNewRelationship] = useState({
    person1Id: '',
    person2Id: '',
    type: 'parent' as 'parent' | 'spouse' | 'child' | 'sibling'
  });

  const loadData = async () => {
    try {
      setLoading(true);
      console.log('Загрузка данных...');
      
      // Загружаем людей
      const personsResponse = await personApi.getAll();
      if (personsResponse.data.success) {
        setPersons(personsResponse.data.data);
        console.log('Люди загружены:', personsResponse.data.data.length);
      }
      
      // Загружаем отношения
      const relationshipsResponse = await relationshipApi.getAll();
      if (relationshipsResponse.data.success) {
        setRelationships(relationshipsResponse.data.data);
        console.log('Отношения загружены:', relationshipsResponse.data.data.length);
      }
      
    } catch (error: any) {
      console.error('Ошибка загрузки:', error);
      alert(`Ошибка: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const addTestPerson = async () => {
    try {
      const names = ['Иван', 'Мария', 'Алексей', 'Ольга', 'Дмитрий', 'Елена'];
      const lastNames = ['Иванов', 'Петров', 'Сидоров', 'Смирнов', 'Кузнецов'];
      
      const personData = {
        firstName: names[Math.floor(Math.random() * names.length)],
        lastName: lastNames[Math.floor(Math.random() * lastNames.length)],
        gender: Math.random() > 0.5 ? 'male' : 'female',
        isAlive: true,
      };
      
      console.log('Добавление человека:', personData);
      await personApi.create(personData);
      await loadData(); // Перезагружаем данные
      
    } catch (error) {
      console.error('Ошибка добавления:', error);
    }
  };

  const createRelationship = async () => {
    if (!newRelationship.person1Id || !newRelationship.person2Id) {
      alert('Выберите обоих людей');
      return;
    }
    
    if (newRelationship.person1Id === newRelationship.person2Id) {
      alert('Нельзя создать отношение человека с самим собой');
      return;
    }
    
    try {
      console.log('Создание отношения:', newRelationship);
      await relationshipApi.create({
        person1Id: parseInt(newRelationship.person1Id),
        person2Id: parseInt(newRelationship.person2Id),
        type: newRelationship.type
      });
      
      // Сброс формы
      setNewRelationship({
        person1Id: '',
        person2Id: '',
        type: 'parent'
      });
      
      // Обновление данных
      await loadData();
      
      alert('Отношение успешно создано!');
      
    } catch (error: any) {
      console.error('Ошибка создания отношения:', error);
      alert(`Ошибка: ${error.response?.data?.message || error.message}`);
    }
  };

  const deleteRelationship = async (id: number) => {
    if (!confirm('Удалить это отношение?')) return;
    
    try {
      console.log('Удаление отношения ID:', id);
      await relationshipApi.delete(id);
      await loadData(); // Перезагружаем данные
      alert('Отношение удалено!');
    } catch (error: any) {
      console.error('Ошибка удаления отношения:', error);
      alert(`Ошибка: ${error.response?.data?.message || error.message}`);
    }
  };

  const deletePerson = async (id: number) => {
    if (!confirm('Удалить этого человека и все его отношения?')) return;
    
    try {
      console.log('Удаление человека ID:', id);
      const response = await personApi.delete(id);
      console.log('Ответ от API:', response.data);
      
      if (response.data.success) {
        // Удаляем человека из состояния сразу
        setPersons(prev => prev.filter(p => p.id !== id));
        // Перезагружаем отношения
        await loadData();
        alert('Человек удален!');
      } else {
        alert('Ошибка удаления: ' + response.data.message);
      }
      
    } catch (error: any) {
      console.error('Ошибка удаления человека:', error);
      alert(`Ошибка: ${error.response?.data?.message || error.message}`);
    }
  };

  const getPersonName = (id: number) => {
    const person = persons.find(p => p.id === id);
    return person ? `${person.firstName} ${person.lastName}` : `ID: ${id}`;
  };

  const getRelationshipTypeText = (type: string) => {
    switch (type) {
      case 'parent': return 'Родитель → Ребенок';
      case 'child': return 'Ребенок → Родитель';
      case 'spouse': return 'Супруг(а)';
      case 'sibling': return 'Брат/Сестра';
      default: return type;
    }
  };

  // Функции для редактирования
  const handleEditPerson = (person: Person) => {
    setEditingPerson(person);
    setIsEditModalOpen(true);
  };

  const handleSavePerson = async () => {
    await loadData(); // Перезагружаем данные после сохранения
  };

  if (loading) {
    return (
      <div style={{ 
        padding: '40px', 
        textAlign: 'center',
        fontSize: '18px'
      }}>
        Загрузка данных...
      </div>
    );
  }

  return (
    <div style={{ 
      padding: '20px', 
      fontFamily: 'Arial, sans-serif',
      maxWidth: '1400px',
      margin: '0 auto'
    }}>
      <h1 style={{ color: '#2e7d32', marginBottom: '10px' }}>🌳 Genealogy App</h1>
      <p style={{ color: '#666', marginBottom: '30px' }}>Управление генеалогическим древом</p>

      {/* Табы */}
      <div style={{ 
        display: 'flex', 
        gap: '10px', 
        marginBottom: '30px',
        borderBottom: '2px solid #e0e0e0',
        paddingBottom: '10px'
      }}>
        <button
          onClick={() => setActiveTab('persons')}
          style={{
            padding: '10px 20px',
            background: activeTab === 'persons' ? '#4CAF50' : '#f5f5f5',
            color: activeTab === 'persons' ? 'white' : '#333',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: activeTab === 'persons' ? 'bold' : 'normal'
          }}
        >
          👥 Люди ({persons.length})
        </button>
        <button
          onClick={() => setActiveTab('relationships')}
          style={{
            padding: '10px 20px',
            background: activeTab === 'relationships' ? '#4CAF50' : '#f5f5f5',
            color: activeTab === 'relationships' ? 'white' : '#333',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: activeTab === 'relationships' ? 'bold' : 'normal'
          }}
        >
          🔗 Отношения ({relationships.length})
        </button>
      </div>

      {/* Контент табов */}
      {activeTab === 'persons' ? (
        <div>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px'
          }}>
            <h2>Управление людьми</h2>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                onClick={addTestPerson}
                style={{
                  padding: '10px 20px',
                  background: '#2196F3',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                + Добавить тестового человека
              </button>
              <button 
                onClick={loadData}
                style={{
                  padding: '10px 20px',
                  background: '#FF9800',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                🔄 Обновить
              </button>
            </div>
          </div>

          {persons.length === 0 ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '40px 20px',
              background: '#f9f9f9',
              borderRadius: '8px'
            }}>
              <p>База данных пуста</p>
              <p>Добавьте первого человека</p>
            </div>
          ) : (
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
              gap: '20px'
            }}>
              {persons.map(person => (
                <div 
                  key={person.id}
                  style={{
                    padding: '20px',
                    background: '#f5f5f5',
                    borderRadius: '8px',
                    border: '1px solid #ddd',
                    position: 'relative'
                  }}
                >
                  {/* Действия с карточкой */}
                  <div style={{
                    position: 'absolute',
                    top: '15px',
                    right: '15px',
                    display: 'flex',
                    gap: '10px'
                  }}>
                    <button
                      onClick={() => handleEditPerson(person)}
                      style={{
                        padding: '6px 12px',
                        background: '#4CAF50',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                      title="Редактировать"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => deletePerson(person.id)}
                      style={{
                        padding: '6px 12px',
                        background: '#f44336',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                      title="Удалить"
                    >
                      🗑️
                    </button>
                  </div>

                  <h3 style={{ marginBottom: '10px', paddingRight: '80px' }}>
                    {person.firstName} {person.middleName || ''} {person.lastName}
                  </h3>
                  
                  <div style={{ fontSize: '14px', color: '#666' }}>
                    <p><strong>ID:</strong> {person.id}</p>
                    <p><strong>Пол:</strong> {person.gender === 'male' ? '♂ Мужской' : person.gender === 'female' ? '♀ Женский' : 'Не указан'}</p>
                    <p><strong>Статус:</strong> 
                      <span style={{
                        display: 'inline-block',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        background: person.isAlive ? '#c8e6c9' : '#ffcdd2',
                        color: person.isAlive ? '#2e7d32' : '#c62828',
                        marginLeft: '8px',
                        fontSize: '12px'
                      }}>
                        {person.isAlive ? 'Жив/а' : 'Умер/ла'}
                      </span>
                    </p>
                    
                    {person.birthDate && (
                      <p><strong>Родился:</strong> {new Date(person.birthDate).toLocaleDateString('ru-RU')}</p>
                    )}
                    
                    {person.birthPlace && (
                      <p><strong>Место рождения:</strong> {person.birthPlace}</p>
                    )}
                    
                    {person.deathDate && (
                      <p><strong>Умер:</strong> {new Date(person.deathDate).toLocaleDateString('ru-RU')}</p>
                    )}
                    
                    {person.biography && (
                      <div style={{ 
                        marginTop: '10px', 
                        padding: '10px',
                        background: 'white',
                        borderRadius: '4px',
                        border: '1px solid #eee'
                      }}>
                        <p style={{ margin: 0, fontSize: '13px', lineHeight: '1.4' }}>
                          {person.biography.length > 100 
                            ? `${person.biography.substring(0, 100)}...` 
                            : person.biography}
                        </p>
                      </div>
                    )}
                    
                    <p style={{ marginTop: '10px', fontSize: '12px', color: '#999' }}>
                      <strong>Добавлен:</strong> {new Date(person.createdAt).toLocaleDateString('ru-RU')}
                      {person.updatedAt !== person.createdAt && (
                        <span> (обновлен: {new Date(person.updatedAt).toLocaleDateString('ru-RU')})</span>
                      )}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px'
          }}>
            <h2>Управление отношениями</h2>
            <button 
              onClick={loadData}
              style={{
                padding: '10px 20px',
                background: '#FF9800',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              🔄 Обновить
            </button>
          </div>
          
          {/* Форма создания отношения */}
          <div style={{ 
            background: '#e8f5e9', 
            padding: '20px', 
            borderRadius: '8px',
            marginBottom: '30px'
          }}>
            <h3 style={{ marginBottom: '15px' }}>Создать новое отношение</h3>
            
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: '1fr 1fr 1fr auto',
              gap: '15px',
              alignItems: 'end'
            }}>
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Первый человек
                </label>
                <select
                  value={newRelationship.person1Id}
                  onChange={(e) => setNewRelationship({...newRelationship, person1Id: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                >
                  <option value="">Выберите...</option>
                  {persons.map(person => (
                    <option key={person.id} value={person.id}>
                      {person.firstName} {person.lastName} (ID: {person.id})
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Тип отношения
                </label>
                <select
                  value={newRelationship.type}
                  onChange={(e) => setNewRelationship({...newRelationship, type: e.target.value as any})}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                >
                  <option value="parent">Родитель → Ребенок</option>
                  <option value="spouse">Супруг(а)</option>
                  <option value="sibling">Брат/Сестра</option>
                </select>
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Второй человек
                </label>
                <select
                  value={newRelationship.person2Id}
                  onChange={(e) => setNewRelationship({...newRelationship, person2Id: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                >
                  <option value="">Выберите...</option>
                  {persons
                    .filter(person => person.id.toString() !== newRelationship.person1Id)
                    .map(person => (
                      <option key={person.id} value={person.id}>
                        {person.firstName} {person.lastName} (ID: {person.id})
                      </option>
                    ))
                  }
                </select>
              </div>
              
              <button
                onClick={createRelationship}
                style={{
                  padding: '10px 20px',
                  background: '#4CAF50',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  height: '40px'
                }}
              >
                Создать
              </button>
            </div>
          </div>

          {/* Список отношений */}
          <div>
            <h3 style={{ marginBottom: '15px' }}>Существующие отношения</h3>
            
            {relationships.length === 0 ? (
              <div style={{ 
                textAlign: 'center', 
                padding: '40px 20px',
                background: '#f9f9f9',
                borderRadius: '8px'
              }}>
                <p>Отношений еще нет</p>
                <p>Создайте первое отношение используя форму выше</p>
              </div>
            ) : (
              <div style={{ 
                overflowX: 'auto',
                background: 'white',
                borderRadius: '8px',
                border: '1px solid #ddd'
              }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#f5f5f5' }}>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>ID</th>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Первый человек</th>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Отношение</th>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Второй человек</th>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Создано</th>
                      <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {relationships.map(rel => (
                      <tr key={rel.id} style={{ borderBottom: '1px solid #eee' }}>
                        <td style={{ padding: '12px' }}>{rel.id}</td>
                        <td style={{ padding: '12px' }}>
                          {getPersonName(rel.person1Id)}
                          <div style={{ fontSize: '12px', color: '#666' }}>ID: {rel.person1Id}</div>
                        </td>
                        <td style={{ padding: '12px' }}>
                          <span style={{
                            padding: '4px 8px',
                            background: 
                              rel.type === 'parent' ? '#e3f2fd' :
                              rel.type === 'spouse' ? '#f3e5f5' :
                              '#e8f5e9',
                            color: 
                              rel.type === 'parent' ? '#1565c0' :
                              rel.type === 'spouse' ? '#7b1fa2' :
                              '#2e7d32',
                            borderRadius: '4px',
                            fontWeight: 'bold'
                          }}>
                            {getRelationshipTypeText(rel.type)}
                          </span>
                        </td>
                        <td style={{ padding: '12px' }}>
                          {getPersonName(rel.person2Id)}
                          <div style={{ fontSize: '12px', color: '#666' }}>ID: {rel.person2Id}</div>
                        </td>
                        <td style={{ padding: '12px', fontSize: '14px', color: '#666' }}>
                          {new Date(rel.createdAt).toLocaleDateString('ru-RU')}
                        </td>
                        <td style={{ padding: '12px' }}>
                          <button
                            onClick={() => deleteRelationship(rel.id)}
                            style={{
                              padding: '6px 12px',
                              background: '#f44336',
                              color: 'white',
                              border: 'none',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                          >
                            Удалить
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Модальное окно редактирования */}
      <EditPersonModal
        person={editingPerson}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSavePerson}
      />

      {/* Информационная панель */}
      <div style={{ 
        marginTop: '40px', 
        padding: '20px', 
        background: '#f5f5f5',
        borderRadius: '8px',
        borderTop: '3px solid #4CAF50'
      }}>
        <h3 style={{ marginBottom: '15px' }}>📊 Системная информация</h3>
        <div style={{ 
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '20px'
        }}>
          <div>
            <p style={{ fontWeight: 'bold', color: '#333' }}>База данных</p>
            <p>Людей: {persons.length}</p>
            <p>Отношений: {relationships.length}</p>
          </div>
          <div>
            <p style={{ fontWeight: 'bold', color: '#333' }}>Backend API</p>
            <p>📍 http://localhost:3001</p>
            <p>✅ /api/persons</p>
            <p>✅ /api/relationships</p>
          </div>
          <div>
            <p style={{ fontWeight: 'bold', color: '#333' }}>Отладка</p>
            <button 
              onClick={() => {
                console.log('Persons:', persons);
                console.log('Relationships:', relationships);
                console.log('API URL:', 'http://localhost:3001/api');
              }}
              style={{
                padding: '8px 16px',
                background: '#FF9800',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Лог в консоль
            </button>
          </div>
        </div>
        
        <div style={{ 
          marginTop: '20px', 
          paddingTop: '15px', 
          borderTop: '1px solid #ddd',
          fontSize: '14px',
          color: '#666'
        }}>
          <p><strong>Отладка:</strong> Откройте консоль браузера (F12) для просмотра логов операций.</p>
        </div>
      </div>
      
      <div style={{ 
        marginTop: '20px', 
        textAlign: 'center',
        fontSize: '12px',
        color: '#999',
        padding: '15px',
        borderTop: '1px solid #eee'
      }}>
        <p>Genealogy App v0.3.1 • Редактирование и удаление • {new Date().toLocaleDateString('ru-RU')}</p>
      </div>
    </div>
  );
}

export default App;

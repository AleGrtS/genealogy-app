# Genealogy App - История изменений

## Версия 1.0.0 - Базовая рабочая версия (2024-02-04)

### ✅ Реализовано:

#### Backend (Node.js + TypeScript)
- [x] Сервер Express с TypeScript
- [x] SQLite база данных
- [x] Модель Person с полями:
  - id, firstName, lastName, middleName
  - gender (male/female/unknown)
  - birthDate, birthPlace
  - deathDate, deathPlace
  - biography, isAlive
  - createdAt, updatedAt

#### API Endpoints (полный CRUD)
- [x] `GET /api/persons` - список всех людей
- [x] `POST /api/persons` - создание человека
- [x] `GET /api/persons/:id` - получение по ID
- [x] `PUT /api/persons/:id` - обновление
- [x] `DELETE /api/persons/:id` - удаление
- [x] `GET /api/health` - проверка здоровья сервера

#### База данных
- [x] SQLite с Sequelize ORM
- [x] Автоматическое создание таблиц
- [x] In-memory fallback при проблемах с БД
- [x] Файл базы: `database.sqlite` в корне проекта

#### Валидация
- [x] Проверка обязательных полей (firstName, lastName)
- [x] Обработка ошибок с понятными сообщениями
- [x] HTTP статус коды (200, 201, 400, 404, 500)

#### Документация
- [x] HTML страница с описанием API (`GET /`)
- [x] Примеры curl команд
- [x] Ссылки на все endpoints

### 🔧 Технический стек:
- **Backend**: Node.js 20+, Express, TypeScript
- **База данных**: SQLite 3, Sequelize ORM
- **Деплой**: Локальный сервер на порту 3001
- **Зависимости**: см. server/package.json

### 🚀 Как запустить:
```bash
cd server
npm install
npm run devПримеры API запросов:
bash

# Создать человека
curl -X POST http://localhost:3001/api/persons \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Иван","lastName":"Иванов"}'

# Получить список
curl http://localhost:3001/api/persons

# Получить по ID
curl http://localhost:3001/api/persons/1

# Обновить
curl -X PUT http://localhost:3001/api/persons/1 \
  -d '{"birthPlace":"Москва"}'

# Удалить
curl -X DELETE http://localhost:3001/api/persons/1

📁 Структура проекта:
text

genealogy-app/
├── server/                    # Backend
│   ├── src/
│   │   ├── config/          # Конфигурация БД
│   │   ├── controllers/     # Контроллеры API
│   │   ├── models/         # Модели данных (Person)
│   │   ├── routes/         # Маршруты API
│   │   └── index.ts        # Главный файл
│   └── package.json
├── client/                  # Frontend (пока пусто)
├── database.sqlite         # Файл базы данных
├── .env                    # Переменные окружения
└── CHANGELOG.md           # Этот файл

⏭️ Следующие шаги:

    Создать React фронтенд

    Добавить отношения между людьми

    Реализовать визуализацию генеалогического древа

    Добавить аутентификацию пользователей

    Реализовать поиск и фильтрацию

o


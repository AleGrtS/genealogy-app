PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE `persons` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `firstName` VARCHAR(255) NOT NULL, `lastName` VARCHAR(255) NOT NULL, `middleName` VARCHAR(255), `gender` VARCHAR(255), `birthDate` DATE, `birthPlace` TEXT, `deathDate` DATE, `deathPlace` TEXT, `biography` TEXT, `isAlive` TINYINT(1) DEFAULT 1, `createdAt` DATETIME NOT NULL, `updatedAt` DATETIME NOT NULL);
INSERT INTO persons VALUES(1,'Петр','Попов','Андрейович','male','1880-07-23','Москва','1965-11-25',NULL,'Ветеран труда.',0,'2026-02-19 22:13:51.577 +00:00','2026-02-19 22:13:51.577 +00:00');
INSERT INTO persons VALUES(2,'Екатерина','Попова','Еленаовна','female','1904-06-13','Новосибирск','1967-03-24',NULL,'Домохозяйка.',0,'2026-02-19 22:13:51.608 +00:00','2026-02-19 22:13:51.608 +00:00');
INSERT INTO persons VALUES(3,'Михаил','Сидоров','Михаилович','male','1885-07-28','Питер','1952-09-22',NULL,'Ветеран труда.',0,'2026-02-19 22:13:51.651 +00:00','2026-02-19 22:13:51.651 +00:00');
INSERT INTO persons VALUES(4,'Екатерина','Сидорова','Марияовна','female','1900-02-12','Екатеринбург','1964-04-08',NULL,'Домохозяйка.',0,'2026-02-19 22:13:51.664 +00:00','2026-02-19 22:13:51.664 +00:00');
INSERT INTO persons VALUES(5,'Андрей','Иванов','Алексейович','male','1893-01-18','Нижний Новгород','1969-03-30',NULL,'Ветеран труда.',0,'2026-02-19 22:13:51.705 +00:00','2026-02-19 22:13:51.705 +00:00');
INSERT INTO persons VALUES(6,'Ирина','Иванова','Иринаовна','female','1887-05-10','Москва','1965-08-08',NULL,'Домохозяйка.',0,'2026-02-19 22:13:51.725 +00:00','2026-02-19 22:13:51.725 +00:00');
INSERT INTO persons VALUES(7,'Михаил','Петров','Михаилович','male','1893-08-25','Екатеринбург','1952-06-11',NULL,'Ветеран труда.',0,'2026-02-19 22:13:51.790 +00:00','2026-02-19 22:13:51.790 +00:00');
INSERT INTO persons VALUES(8,'Анна','Петрова','Еленаовна','female','1901-04-26','Нижний Новгород','1967-05-29',NULL,'Домохозяйка.',0,'2026-02-19 22:13:51.815 +00:00','2026-02-19 22:13:51.815 +00:00');
INSERT INTO persons VALUES(9,'Ольга','Попов','Петровна','female','1923-02-21','Москва','2003-07-20',NULL,'Рабочий.',0,'2026-02-19 22:13:51.856 +00:00','2026-02-19 22:13:51.856 +00:00');
INSERT INTO persons VALUES(10,'Ольга','Попов','Петровна','female','1932-05-22','Питер','1997-10-17',NULL,'Рабочий.',0,'2026-02-19 22:13:51.907 +00:00','2026-02-19 22:13:51.907 +00:00');
INSERT INTO persons VALUES(11,'Наталья','Сидоров','Михаиловна','female','1938-08-03','Нижний Новгород','2001-06-24',NULL,'Рабочий.',0,'2026-02-19 22:13:51.967 +00:00','2026-02-19 22:13:51.967 +00:00');
INSERT INTO persons VALUES(12,'Екатерина','Сидоров','Михаиловна','female','1932-11-04','Нижний Новгород','1994-08-16',NULL,'Рабочий.',0,'2026-02-19 22:13:52.016 +00:00','2026-02-19 22:13:52.016 +00:00');
INSERT INTO persons VALUES(13,'Наталья','Иванов','Андрейовна','female','1924-08-31','Москва','1994-02-18',NULL,'Рабочий.',0,'2026-02-19 22:13:52.079 +00:00','2026-02-19 22:13:52.079 +00:00');
INSERT INTO persons VALUES(14,'Алексей','Иванов','Андрейович','male','1925-03-31','Новосибирск','2010-02-13',NULL,'Рабочий.',0,'2026-02-19 22:13:52.136 +00:00','2026-02-19 22:13:52.136 +00:00');
INSERT INTO persons VALUES(15,'Михаил','Петров','Михаилович','male','1920-07-26','Казань','1993-10-06',NULL,'Рабочий.',0,'2026-02-19 22:13:52.188 +00:00','2026-02-19 22:13:52.188 +00:00');
INSERT INTO persons VALUES(16,'Михаил','Петров','Михаилович','male','1933-01-02','Казань','1994-04-05',NULL,'Рабочий.',0,'2026-02-19 22:13:52.252 +00:00','2026-02-19 22:13:52.252 +00:00');
INSERT INTO persons VALUES(17,'Анна','Попов','Ольгаовна','female','1973-02-06','Москва',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.302 +00:00','2026-02-19 22:13:52.302 +00:00');
INSERT INTO persons VALUES(18,'Алексей','Попов','Ольгаович','male','1968-01-28','Новосибирск',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.355 +00:00','2026-02-19 22:13:52.355 +00:00');
INSERT INTO persons VALUES(19,'Мария','Сидоров','Натальяовна','female','1965-12-16','Питер',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.408 +00:00','2026-02-19 22:13:52.408 +00:00');
INSERT INTO persons VALUES(20,'Иван','Сидоров','Натальяович','male','1962-11-27','Новосибирск',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.462 +00:00','2026-02-19 22:13:52.462 +00:00');
INSERT INTO persons VALUES(21,'Андрей','Иванов','Натальяович','male','1980-02-17','Москва',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.517 +00:00','2026-02-19 22:13:52.517 +00:00');
INSERT INTO persons VALUES(22,'Елена','Иванов','Натальяовна','female','1980-01-28','Москва',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.567 +00:00','2026-02-19 22:13:52.567 +00:00');
INSERT INTO persons VALUES(23,'Елена','Петров','Михаиловна','female','1963-09-14','Екатеринбург',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.612 +00:00','2026-02-19 22:13:52.612 +00:00');
INSERT INTO persons VALUES(24,'Петр','Петров','Михаилович','male','1980-05-30','Новосибирск',NULL,NULL,'Современный работник.',1,'2026-02-19 22:13:52.671 +00:00','2026-02-19 22:13:52.671 +00:00');
INSERT INTO persons VALUES(25,'Алексей','Попов','Аннаович','male','2001-03-17','Екатеринбург',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.720 +00:00','2026-02-19 22:13:52.720 +00:00');
INSERT INTO persons VALUES(26,'Алексей','Попов','Алексейович','male','2006-04-07','Нижний Новгород',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.753 +00:00','2026-02-19 22:13:52.753 +00:00');
INSERT INTO persons VALUES(27,'Алексей','Сидоров','Марияович','male','2008-08-26','Нижний Новгород',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.786 +00:00','2026-02-19 22:13:52.786 +00:00');
INSERT INTO persons VALUES(28,'Николай','Сидоров','Иванович','male','2007-12-12','Москва',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.820 +00:00','2026-02-19 22:13:52.820 +00:00');
INSERT INTO persons VALUES(29,'Андрей','Иванов','Андрейович','male','2003-08-12','Москва',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.849 +00:00','2026-02-19 22:13:52.849 +00:00');
INSERT INTO persons VALUES(30,'Андрей','Иванов','Еленаович','male','2009-05-11','Нижний Новгород',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.884 +00:00','2026-02-19 22:13:52.884 +00:00');
INSERT INTO persons VALUES(31,'Алексей','Петров','Еленаович','male','2000-12-16','Нижний Новгород',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.917 +00:00','2026-02-19 22:13:52.917 +00:00');
INSERT INTO persons VALUES(32,'Петр','Петров','Петрович','male','2007-04-10','Екатеринбург',NULL,NULL,'Ребенок.',1,'2026-02-19 22:13:52.949 +00:00','2026-02-19 22:13:52.949 +00:00');
CREATE TABLE `relationships` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `person1Id` INTEGER NOT NULL REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE, `person2Id` INTEGER NOT NULL REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE, `type` VARCHAR(255) NOT NULL, `startDate` DATE, `endDate` DATE, `notes` TEXT, `createdAt` DATETIME NOT NULL, `updatedAt` DATETIME NOT NULL);
INSERT INTO relationships VALUES(1,1,2,'spouse',NULL,NULL,NULL,'2026-02-19 22:13:51.627 +00:00','2026-02-19 22:13:51.627 +00:00');
INSERT INTO relationships VALUES(2,3,4,'spouse',NULL,NULL,NULL,'2026-02-19 22:13:51.683 +00:00','2026-02-19 22:13:51.683 +00:00');
INSERT INTO relationships VALUES(3,5,6,'spouse',NULL,NULL,NULL,'2026-02-19 22:13:51.740 +00:00','2026-02-19 22:13:51.740 +00:00');
INSERT INTO relationships VALUES(4,7,8,'spouse',NULL,NULL,NULL,'2026-02-19 22:13:51.834 +00:00','2026-02-19 22:13:51.834 +00:00');
INSERT INTO relationships VALUES(5,1,9,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.877 +00:00','2026-02-19 22:13:51.877 +00:00');
INSERT INTO relationships VALUES(6,2,9,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.890 +00:00','2026-02-19 22:13:51.890 +00:00');
INSERT INTO relationships VALUES(7,1,10,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.923 +00:00','2026-02-19 22:13:51.923 +00:00');
INSERT INTO relationships VALUES(8,2,10,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.946 +00:00','2026-02-19 22:13:51.946 +00:00');
INSERT INTO relationships VALUES(9,3,11,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.980 +00:00','2026-02-19 22:13:51.980 +00:00');
INSERT INTO relationships VALUES(10,4,11,'parent',NULL,NULL,NULL,'2026-02-19 22:13:51.995 +00:00','2026-02-19 22:13:51.995 +00:00');
INSERT INTO relationships VALUES(11,3,12,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.033 +00:00','2026-02-19 22:13:52.033 +00:00');
INSERT INTO relationships VALUES(12,4,12,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.056 +00:00','2026-02-19 22:13:52.056 +00:00');
INSERT INTO relationships VALUES(13,5,13,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.096 +00:00','2026-02-19 22:13:52.096 +00:00');
INSERT INTO relationships VALUES(14,6,13,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.116 +00:00','2026-02-19 22:13:52.116 +00:00');
INSERT INTO relationships VALUES(15,5,14,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.152 +00:00','2026-02-19 22:13:52.152 +00:00');
INSERT INTO relationships VALUES(16,6,14,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.174 +00:00','2026-02-19 22:13:52.174 +00:00');
INSERT INTO relationships VALUES(17,7,15,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.213 +00:00','2026-02-19 22:13:52.213 +00:00');
INSERT INTO relationships VALUES(18,8,15,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.228 +00:00','2026-02-19 22:13:52.228 +00:00');
INSERT INTO relationships VALUES(19,7,16,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.271 +00:00','2026-02-19 22:13:52.271 +00:00');
INSERT INTO relationships VALUES(20,8,16,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.286 +00:00','2026-02-19 22:13:52.286 +00:00');
INSERT INTO relationships VALUES(21,9,17,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.320 +00:00','2026-02-19 22:13:52.320 +00:00');
INSERT INTO relationships VALUES(22,10,17,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.337 +00:00','2026-02-19 22:13:52.337 +00:00');
INSERT INTO relationships VALUES(23,9,18,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.369 +00:00','2026-02-19 22:13:52.369 +00:00');
INSERT INTO relationships VALUES(24,10,18,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.388 +00:00','2026-02-19 22:13:52.388 +00:00');
INSERT INTO relationships VALUES(25,11,19,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.426 +00:00','2026-02-19 22:13:52.426 +00:00');
INSERT INTO relationships VALUES(26,12,19,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.445 +00:00','2026-02-19 22:13:52.445 +00:00');
INSERT INTO relationships VALUES(27,11,20,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.482 +00:00','2026-02-19 22:13:52.482 +00:00');
INSERT INTO relationships VALUES(28,12,20,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.501 +00:00','2026-02-19 22:13:52.501 +00:00');
INSERT INTO relationships VALUES(29,13,21,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.527 +00:00','2026-02-19 22:13:52.527 +00:00');
INSERT INTO relationships VALUES(30,14,21,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.544 +00:00','2026-02-19 22:13:52.544 +00:00');
INSERT INTO relationships VALUES(31,13,22,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.581 +00:00','2026-02-19 22:13:52.581 +00:00');
INSERT INTO relationships VALUES(32,14,22,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.598 +00:00','2026-02-19 22:13:52.598 +00:00');
INSERT INTO relationships VALUES(33,15,23,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.634 +00:00','2026-02-19 22:13:52.634 +00:00');
INSERT INTO relationships VALUES(34,16,23,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.651 +00:00','2026-02-19 22:13:52.651 +00:00');
INSERT INTO relationships VALUES(35,15,24,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.689 +00:00','2026-02-19 22:13:52.689 +00:00');
INSERT INTO relationships VALUES(36,16,24,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.707 +00:00','2026-02-19 22:13:52.707 +00:00');
INSERT INTO relationships VALUES(37,17,25,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.739 +00:00','2026-02-19 22:13:52.739 +00:00');
INSERT INTO relationships VALUES(38,18,26,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.771 +00:00','2026-02-19 22:13:52.771 +00:00');
INSERT INTO relationships VALUES(39,19,27,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.800 +00:00','2026-02-19 22:13:52.800 +00:00');
INSERT INTO relationships VALUES(40,20,28,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.835 +00:00','2026-02-19 22:13:52.835 +00:00');
INSERT INTO relationships VALUES(41,21,29,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.866 +00:00','2026-02-19 22:13:52.866 +00:00');
INSERT INTO relationships VALUES(42,22,30,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.897 +00:00','2026-02-19 22:13:52.897 +00:00');
INSERT INTO relationships VALUES(43,23,31,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.933 +00:00','2026-02-19 22:13:52.933 +00:00');
INSERT INTO relationships VALUES(44,24,32,'parent',NULL,NULL,NULL,'2026-02-19 22:13:52.963 +00:00','2026-02-19 22:13:52.963 +00:00');
CREATE TABLE photos (
  id CHAR(36) PRIMARY KEY,
  personId INTEGER NOT NULL,
  filename VARCHAR(255) NOT NULL,
  originalName VARCHAR(255) NOT NULL,
  path VARCHAR(500) NOT NULL,
  thumbnailPath VARCHAR(500) NOT NULL,
  size INTEGER NOT NULL,
  mimeType VARCHAR(100) NOT NULL,
  isMain BOOLEAN DEFAULT 0,
  caption TEXT,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (personId) REFERENCES persons(id) ON DELETE CASCADE
);
INSERT INTO photos VALUES('05b84502-5453-42ba-8532-d374850604a4',1,'4dde3cbf-5bb8-4134-8b50-ed42279fca1f.png','test.png','/uploads/photos/4dde3cbf-5bb8-4134-8b50-ed42279fca1f.png','/uploads/photos/4dde3cbf-5bb8-4134-8b50-ed42279fca1f.png',70,'image/png',0,NULL,'2026-02-20 17:49:32.720 +00:00','2026-02-20 17:49:32.720 +00:00');
INSERT INTO photos VALUES('f6a54fe9-6b95-44cf-87c2-6436ef4fd426',32,'c15ecec1-48d5-46b3-8849-16ad901f900d.png','Screenshot from 2026-02-18 22-22-36.png','/uploads/photos/c15ecec1-48d5-46b3-8849-16ad901f900d.png','/uploads/photos/c15ecec1-48d5-46b3-8849-16ad901f900d.png',164559,'image/png',0,NULL,'2026-02-20 17:50:45.721 +00:00','2026-02-20 17:50:45.721 +00:00');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('persons',32);
INSERT INTO sqlite_sequence VALUES('relationships',44);
COMMIT;

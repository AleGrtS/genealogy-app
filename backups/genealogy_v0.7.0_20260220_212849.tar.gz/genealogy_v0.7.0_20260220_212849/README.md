# 🌳 Genealogy App - Резервная копия v0.7.0

## 📋 Информация
- **Дата создания:** Fri Feb 20 09:28:50 PM EET 2026
- **Версия:** 0.7.0
- **Название:** Статистика и аналитика

## 📊 Статистика базы данных
- 👥 Людей: 32
- 🔗 Отношений: 44
- 📸 Фотографий: 2

## 🛠 Технологии
### Backend
- Node.js + Express + TypeScript
- SQLite + Sequelize ORM
- Multer для загрузки файлов

### Frontend
- React 19 + TypeScript
- Vite (сборщик)
- vis-network (визуализация дерева)
- Axios (HTTP клиент)

## ✨ Реализованный функционал
- ✅ Управление людьми (CRUD)
- ✅ Управление отношениями (родитель, супруг, брат/сестра)
- ✅ Визуализация семейного дерева (интерактивное)
- ✅ Загрузка и управление фотографиями
- ✅ Поиск и фильтрация людей
- ✅ Статистика и аналитика (v0.7.0)

## 📁 Структура бэкапа
```
genealogy_v0.7.0_20260220_212849/
├── server/          # Backend код
├── client/          # Frontend код
├── uploads/         # Загруженные фотографии
├── database/        # База данных SQLite
├── scripts/         # Вспомогательные скрипты
└── docs/            # Документация и Git информация
```

## 🚀 Восстановление
```bash
# Распаковать архив
tar -xzf genealogy_v0.7.0_20260220_212849.tar.gz

# Восстановить файлы
cp -r genealogy_v0.7.0_20260220_212849/server/* /var/www/genealogy-app/server/
cp -r genealogy_v0.7.0_20260220_212849/client/* /var/www/genealogy-app/client/
cp -r genealogy_v0.7.0_20260220_212849/uploads/* /var/www/genealogy-app/server/uploads/
cp genealogy_v0.7.0_20260220_212849/database/database.sqlite /var/www/genealogy-app/server/

# Установить зависимости
cd /var/www/genealogy-app/server && npm install
cd /var/www/genealogy-app/client && npm install

# Запустить
cd /var/www/genealogy-app/server && npm run dev
cd /var/www/genealogy-app/client && npm run dev
```

## 🔗 API Endpoints
- `GET /api/health` - проверка сервера
- `GET /api/persons` - список людей
- `POST /api/persons` - создать человека
- `GET /api/relationships` - список отношений
- `POST /api/photos/:personId` - загрузить фото

## 📝 Последние изменения (v0.7.0)
- Добавлен раздел статистики
- Общая статистика по людям и отношениям
- Распределение по полу (круговая диаграмма)
- Топ многодетных родителей
- Счетчик поколений
